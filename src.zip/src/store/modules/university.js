import ApiService from '@/services/ApiService'

export const namespaced = true

export const state = {
  universities: [],
  userUniversity: {}
}
export const mutations = {
  SET_UNIVERSITIES(state, universities) {
    state.universities = universities
  },

  SET_USER_UNIVERSITY(state, userUniversity) {
    state.userUniversity = userUniversity
  }
}
export const actions = {
  fetchUniversities({ commit }) {
    return ApiService.fetchUniversities()
      .then(response => {
        commit('SET_UNIVERSITIES', response.data.results)
      })
      .catch(error => {
        throw error
      })
  },

  fetchUserUniversity({ commit }, id) {
    return ApiService.fetchUserUniversity(id)
      .then(response => {
        commit('SET_USER_UNIVERSITY', response.data)
      })
      .catch(error => {
        throw error
      })
  }
}
export const getters = {
  universities(state) {
    return state.universities
  }
}
