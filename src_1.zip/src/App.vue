<template>
  <v-app>
    <TheAppBar />
    <v-main>
      <router-view :key="$route.fullPath" />
    </v-main>
  </v-app>
</template>

<script>
export default {
  components: {
    TheAppBar: () => import('@/components/TheAppBar.vue')
  }
}
</script>
