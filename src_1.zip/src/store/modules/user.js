import ApiService from '@/services/ApiService.js'

export const namespaced = true

export const state = {
  user: {}
}
export const mutations = {
  SET_USER(state, user) {
    state.user = user
  }
}
export const actions = {
  fetchUser({ commit }, id) {
    return ApiService.fetchUser(id)
      .then(response => {
        commit('SET_USER', response.data)
      })
      .catch(error => {
        throw error
      })
  },

  updateUser(context, { id, newUserData }) {
    return ApiService.updateUser(id, newUserData)
  }
}
export const getters = {}
