import TokenService from '@/services/TokenService'
import ApiService from '@/services/ApiService'
import jwtDecode from 'jwt-decode'

export const namespaced = true

export const state = {
  user: false,
  userId: null
}
export const mutations = {
  SET_AUTH_USER(state) {
    state.user = true
  },

  SET_USER_ID(state, userId) {
    state.userId = userId
  },

  LOGOUT() {
    TokenService.removeToken('access')
    TokenService.removeToken('refresh')
    location.reload()
  }
}
export const actions = {
  login({ commit }, credentials) {
    return ApiService.login(credentials)
      .then(response => {
        const userId = jwtDecode(response.data.access).user_id
        ApiService.ApiService.defaults.headers.common[
          'Authorization'
        ] = `Bearer ${response.data.access}`
        TokenService.saveToken('access', response.data.access)
        TokenService.saveToken('refresh', response.data.refresh)
        commit('SET_AUTH_USER')
        commit('SET_USER_ID', userId)
      })
      .catch(error => {
        throw error
      })
  },

  register(context, credentials) {
    return ApiService.register(credentials).then(() => {})
  },

  refreshToken({ commit }, refresh) {
    return ApiService.refreshToken(refresh)
      .then(response => {
        const userId = jwtDecode(response.data.access).user_id
        ApiService.ApiService.defaults.headers.common[
          'Authorization'
        ] = `Bearer ${response.data.access}`
        TokenService.saveToken('access', response.data.access)
        commit('SET_USER_ID', userId)
      })
      .catch(error => {
        throw error
      })
  },

  logout({ commit }) {
    commit('LOGOUT')
  },

  emailConfirm(context, credentials) {
    return ApiService.emailConfirm(credentials)
      .then(() => {})
      .catch(error => {
        throw error
      })
  },

  resetPassword(context, email) {
    return ApiService.resetPassword(email)
      .then(() => {})
      .catch(error => {
        throw error
      })
  },

  resetPasswordConfirm(context, credentials) {
    return ApiService.resetPasswordConfirm(credentials)
      .then(() => {})
      .catch(error => {
        throw error
      })
  }
}
export const getters = {}
